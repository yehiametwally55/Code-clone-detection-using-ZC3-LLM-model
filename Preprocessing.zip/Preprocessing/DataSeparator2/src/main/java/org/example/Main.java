package org.example;

import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) {
        // Path to the input JSON file
        String inputFilePath = "/C:/Users/yehia/Downloads/AtCoderTest.jsonl";

        // Output file paths
        String domain0FilePath = "C:/Users/yehia/OneDrive/Desktop/DataSeparator2/src/main/resources/AtCoderQueries.json";
        String domain1FilePath = "C:/Users/yehia/OneDrive/Desktop/DataSeparator2/src/main/resources/AtCoderCandidates.json";

        int maxRecords = 5000; // Maximum records to process
        int recordCount = 0; // Counter for processed records

        try {
            // Create readers and writers (UTF-8 encoding)
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new FileInputStream(inputFilePath), StandardCharsets.UTF_8));
            BufferedWriter domain0Writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(domain0FilePath), StandardCharsets.UTF_8));
            BufferedWriter domain1Writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(domain1FilePath), StandardCharsets.UTF_8));

            String line;

            // Iterate through each line in the input file
            while ((line = reader.readLine()) != null) {
                // Parse the line as a JSON object
                JSONObject jsonObject = new JSONObject(line);

                // Check the domain_label value and write to the respective file
                int domainLabel = jsonObject.getInt("domain_label");
                if (domainLabel == 0) {
                    domain0Writer.write(jsonObject.toString());
                    domain0Writer.newLine(); // Add a new line after each object
                } else if (domainLabel == 1) {
                    domain1Writer.write(jsonObject.toString());
                    domain1Writer.newLine(); // Add a new line after each object
                }

                // Increment the record count

            }

            // Close the readers and writers
            reader.close();
            domain0Writer.close();
            domain1Writer.close();

            System.out.println("✅ Data successfully separated into Queries.json and Candidates.json with 50 records.");
        } catch (IOException e) {
            throw new RuntimeException("Error processing the file: " + e.getMessage());
        }
    }
}