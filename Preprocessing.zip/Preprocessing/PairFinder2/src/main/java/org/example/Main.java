package org.example;

import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
//        String inputFilePath = "C:/Users/yehia/Downloads/JsonTransformer/JsonTransformer/src/main/resources/NewTrain2.jsonl";  // Change this to your JSON file path
//        String outputFilePath = "C:/Users/yehia/Downloads/JsonTransformer/JsonTransformer/src/main/resources/FilteredTrain2.jsonl";  // Change this to the desired output file path
//
//        HashMap<String, Integer> labelCount = new HashMap<>();
//        List<String> validLines = new ArrayList<>();
//
//        try (BufferedReader br = new BufferedReader(new FileReader(inputFilePath))) {
//            String line;
//
//            // First pass: Count occurrences of each label
//            while ((line = br.readLine()) != null) {
//                JSONObject jsonObject = new JSONObject(line);
//                String label = jsonObject.getString("label");
//
//                // Count occurrences
//                labelCount.put(label, labelCount.getOrDefault(label, 0) + 1);
//            }
//
//            // Second pass: Filter out lines with labels that appear less than 4 times
//            br.close();  // Close the reader from the first pass
//
//            try (BufferedReader brAgain = new BufferedReader(new FileReader(inputFilePath))) {
//                while ((line = brAgain.readLine()) != null) {
//                    JSONObject jsonObject = new JSONObject(line);
//                    String label = jsonObject.getString("label");
//
//                    if (labelCount.get(label) >= 4) {
//                        validLines.add(line);
//                    }
//                }
//            }
//
//            // Write the valid lines to a new file in UTF-8 encoding
//            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFilePath), StandardCharsets.UTF_8))) {
//                for (String validLine : validLines) {
//                    writer.write(validLine);
//                    writer.newLine();  // Ensure each line is written on a new line
//                }
//            }
//
//            System.out.println("Filtered lines saved to: " + outputFilePath);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}


        String filePath = "/C:/Users/yehia/Downloads/TrainingFinalCombined_filtered.json/";  // Change this to your JSON file path

        HashMap<Integer, Integer> labelCount = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Read file line by line
            while ((line = br.readLine()) != null) {
                JSONObject jsonObject = new JSONObject(line);

                // Get label as int
                int label = jsonObject.getInt("label");

                // Count occurrences
                labelCount.put(label, labelCount.getOrDefault(label, 0) + 1);
            }
            int count =0;
            // Print labels appearing less than 4 times
            System.out.println("Labels that appear less than 4 times:");
            for (Map.Entry<Integer, Integer> entry : labelCount.entrySet()) {
                if (entry.getValue() < 4) {
                    System.out.println("Label: " + entry.getKey() + ", Count: " + entry.getValue());
                    count++;
                }
            }
            System.out.println(count);
        } catch (IOException e) {
            e.printStackTrace();
}

        }
}

