package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        String queriesFilePath = "/C:/Users/yehia/Downloads/Candidates.json";
        String newTestFilePath = "/C:/Users/yehia/Downloads/NewTest.jsonl";

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            Set<String> queriesKeys = extractKeysFromJsonl(objectMapper, queriesFilePath);
            Set<String> newTestKeys = extractKeysFromJsonl(objectMapper, newTestFilePath);

            if (queriesKeys.equals(newTestKeys)) {
                System.out.println("Both files have consistent structures.");
            } else {
                System.out.println("There is a structural inconsistency between the files.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    private static Set<String> extractKeysFromJsonl(ObjectMapper objectMapper, String filePath) throws IOException {
        Set<String> keys = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(new File(filePath)))) {
            String line;
            while ((line = reader.readLine()) != null) {
                JsonNode jsonNode = objectMapper.readTree(line);
                jsonNode.fieldNames().forEachRemaining(keys::add);
            }
        }
        return keys;
    }
}
