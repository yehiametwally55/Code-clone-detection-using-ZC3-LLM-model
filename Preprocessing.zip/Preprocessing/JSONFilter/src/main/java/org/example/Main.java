package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
        String inputFileName = "/C:/Users/yehia/Downloads/TrainingFinalCombined.json/"; // Input file
        String outputFileName = "/C:/Users/yehia/Downloads/TrainingFinalCombined_filtered.json"; // Output file
         // Maximum entries to include
        int minOccurrences = 4; // Minimum label occurrences to include

        try {
            List<JsonNode> dataList = readJsonlFile(inputFileName);
            Map<String, List<JsonNode>> labelMap = groupByLabel(dataList);

            // Filter labels that occur at least 4 times and collect all their data
            List<JsonNode> filteredData = getDataForValidLabels(labelMap, minOccurrences);

            // Limit to 200 records if needed
//            List<JsonNode> finalData = filteredData.stream()
//                    .limit(targetCount)
//                    .collect(Collectors.toList());

            writeJsonlFile(outputFileName, filteredData);
            System.out.println("✅ Data successfully written to " + outputFileName);

        } catch (IOException e) {
            System.err.println("Error processing the file: " + e.getMessage());
        }
    }

    // Read JSONL file and parse each line
    private static List<JsonNode> readJsonlFile(String fileName) throws IOException {
        List<JsonNode> dataList = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(fileName), StandardCharsets.UTF_8))) {

            String line;
            while ((line = reader.readLine()) != null) {
                JsonNode jsonNode = mapper.readTree(line);
                dataList.add(jsonNode);
            }
        }
        return dataList;
    }

    // Group data by the 'label' field
    private static Map<String, List<JsonNode>> groupByLabel(List<JsonNode> dataList) {
        return dataList.stream()
                .filter(json -> json.has("label"))  // Ensure the label field exists
                .collect(Collectors.groupingBy(json -> json.get("label").asText()));
    }

    // Get all data for labels that appear at least 'minOccurrences' times
    private static List<JsonNode> getDataForValidLabels(Map<String, List<JsonNode>> labelMap, int minOccurrences) {
        List<JsonNode> validData = new ArrayList<>();

        for (Map.Entry<String, List<JsonNode>> entry : labelMap.entrySet()) {
            List<JsonNode> items = entry.getValue();

            // Include all items for labels that meet the occurrence condition
            if (items.size() >= minOccurrences) {
                validData.addAll(items);
            }
        }
        return validData;
    }

    // Write the output to a JSONL file with UTF-8 encoding
    private static void writeJsonlFile(String fileName, List<JsonNode> dataList) throws IOException {
        ObjectMapper mapper = new ObjectMapper();

        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(fileName), StandardCharsets.UTF_8))) {

            for (JsonNode jsonNode : dataList) {
                writer.write(mapper.writeValueAsString(jsonNode));
                writer.newLine();
            }
        }
    }
}
