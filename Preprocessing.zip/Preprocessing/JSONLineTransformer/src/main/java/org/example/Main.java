package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get input file path
        System.out.print("Enter input JSON file path: ");
        String inputFilePath = scanner.nextLine();

        // Generate output file path
        String outputFilePath = inputFilePath.replace(".json", "_fixed.json");

        try {
            // Read and parse JSON
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(new File(inputFilePath));

            // Transform JSON
            JsonNode transformedJson = transformJson(jsonNode);

            // Save transformed JSON to a new file
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(outputFilePath), transformedJson);

            System.out.println("✅ JSON transformed successfully!");
            System.out.println("📂 Fixed JSON saved at: " + outputFilePath);
        } catch (IOException e) {
            System.err.println("❌ Error processing JSON file: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    // Method to transform JSON
    private static JsonNode transformJson(JsonNode jsonNode) {
        if (jsonNode.isObject()) {
            ObjectNode objectNode = (ObjectNode) jsonNode;

            // Example Transformations:
            if (objectNode.has("oldKey")) {
                objectNode.set("newKey", objectNode.get("oldKey")); // Rename field
                objectNode.remove("oldKey"); // Remove old field
            }

            if (objectNode.has("age")) {
                int age = objectNode.get("age").asInt();
                objectNode.put("age", age + 1); // Modify value
            }

            objectNode.put("status", "Processed"); // Add new key-value pair
        }

        return jsonNode;
    }
}
