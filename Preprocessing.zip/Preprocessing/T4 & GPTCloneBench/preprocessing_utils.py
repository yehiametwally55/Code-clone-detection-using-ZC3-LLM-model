import os
import json
import re

#########################################
# ========== T4 DATASET PREPROCESSING ==========
# The following functions were used to process the T4 dataset, 
# including semantic and cross-language Type-4 clones.
#########################################

def convert_java_clones_to_train_json(input_folder, output_file):
    """
    Used for T4 training data:
    Converts Java files with two blocks of code into JSONL format.
    Assumes each file contains one functionally equivalent pair.
    
    → Used for files like:
        - Train_T4P2.json
    """
    index = 0
    label_id = 0
    entries = []

    for filename in os.listdir(input_folder):
        if filename.endswith(".java"):
            file_path = os.path.join(input_folder, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()

            blocks = re.split(r"\n\s*\n\s*\n+", content.strip())

            for domain_label, block in enumerate(blocks[:2]):
                if block.strip():
                    entries.append({
                        "index": index,
                        "label": label_id,
                        "domain_label": domain_label,
                        "description": "java",
                        "code": block.strip()
                    })
                    index += 1

            label_id += 1

    with open(output_file, "w", encoding="utf-8") as out:
        for entry in entries:
            json.dump(entry, out)
            out.write("\n")

    print(f"✅ Converted {len(entries)} entries from Java files into {output_file}")


def convert_java_clones_to_balanced_train_json(input_folder, output_file):
    """
    Used for T4 cross-language clone training (e.g., C#):
    Reads C# files and creates balanced samples with flipped domain labels.

    → Used for files like:
        - TrainCSP2.json
    """
    index = 0
    label_id = 0
    entries = []

    for filename in os.listdir(input_folder):
        if filename.endswith(".cs"):
            file_path = os.path.join(input_folder, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()

            blocks = re.split(r"\n\s*\n\s*\n+", content.strip())

            if len(blocks) >= 2:
                block_0 = blocks[0].strip()
                block_1 = blocks[1].strip()

                for code_block, flipped_label in [(block_0, 0), (block_0, 1), (block_1, 0), (block_1, 1)]:
                    entries.append({
                        "index": index,
                        "label": label_id,
                        "domain_label": flipped_label,
                        "description": "java",
                        "code": code_block
                    })
                    index += 1
                label_id += 1

    with open(output_file, "w", encoding="utf-8") as out:
        for entry in entries:
            json.dump(entry, out)
            out.write("\n")

    print(f"✅ Created balanced dataset with {len(entries)} entries in {output_file}")


#########################################
# ========== SEMANTIC DATASET (GPTCloneBench) ==========
# The following functions are used for creating training and test JSONL files
# from folders containing language-paired annotated code (e.g., Java → Python, C#, etc.)
#########################################

def convert_csharp_folder_to_train_json(input_folder, output_file):
    """
    Used for semantic clone dataset (e.g., GPTCloneBench): C# side.
    Parses annotated C# files with multiple translated versions to generate JSONL.

    → Used to generate:
        - TrainC.json
    """
    index = 0
    label_id = 0
    entries = []

    language_markers = {
        "python": ["//python", "python:", "python implementation:"],
        "c": ["//c", "c:", "c implementation:"],
        "java": ["//java", "java:", "java implementation:"]
    }

    for filename in os.listdir(input_folder):
        if filename.endswith(".cs"):
            file_path = os.path.join(input_folder, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            current_lang = "c#"
            current_code = []

            for line in lines:
                line_strip = line.strip().lower()
                matched_lang = None

                for lang, markers in language_markers.items():
                    if any(marker in line_strip for marker in markers):
                        matched_lang = lang
                        break

                if matched_lang:
                    if current_code:
                        entries.append({
                            "index": index,
                            "label": label_id,
                            "domain_label": 0 if current_lang == "c#" else 1,
                            "description": current_lang,
                            "code": "".join(current_code).strip()
                        })
                        index += 1
                    current_code = []
                    current_lang = matched_lang
                    continue

                current_code.append(line)

            if current_code:
                entries.append({
                    "index": index,
                    "label": label_id,
                    "domain_label": 0 if current_lang == "c#" else 1,
                    "description": current_lang,
                    "code": "".join(current_code).strip()
                })
                index += 1
            label_id += 1

    with open(output_file, "w", encoding="utf-8") as out_file:
        for entry in entries:
            json.dump(entry, out_file)
            out_file.write("\n")

    print(f"✅ Converted {len(entries)} entries from C# folder to {output_file}")


def convert_java_folder_to_train_json(input_folder, output_file):
    """
    Used for semantic clone dataset (e.g., GPTCloneBench): Java side.
    Parses annotated Java files with multiple language implementations.
    
    → Used to generate:
        - TrainJava.json
    """
    index = 0
    label_id = 0
    entries = []

    language_markers = {
        "python": ["python:", "python implementation:"],
        "c#": ["c#:", "c# implementation:"],
        "c": ["c:", "c implementation:"]
    }

    for filename in os.listdir(input_folder):
        if filename.endswith(".java"):
            file_path = os.path.join(input_folder, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            current_lang = "java"
            current_code = []

            for line in lines:
                line_strip = line.strip().lower()
                matched_lang = None

                for lang, markers in language_markers.items():
                    if any(marker in line_strip for marker in markers):
                        matched_lang = lang
                        break

                if matched_lang:
                    if current_code:
                        entries.append({
                            "index": index,
                            "label": label_id,
                            "domain_label": 0 if current_lang == "java" else 1,
                            "description": current_lang,
                            "code": "".join(current_code).strip()
                        })
                        index += 1
                    current_code = []
                    current_lang = matched_lang
                    continue

                current_code.append(line)

            if current_code:
                entries.append({
                    "index": index,
                    "label": label_id,
                    "domain_label": 0 if current_lang == "java" else 1,
                    "description": current_lang,
                    "code": "".join(current_code).strip()
                })
                index += 1
            label_id += 1

    with open(output_file, "w", encoding="utf-8") as out_file:
        for entry in entries:
            json.dump(entry, out_file)
            out_file.write("\n")

    print(f"✅ Converted {len(entries)} entries from Java folder to {output_file}")


#########################################
# ========== COMBINE & SPLIT UTILITIES ==========
#########################################

def combine_multiple_parts(input_files, output_file):
    """
    Used to combine JSONL files for T4 or semantic datasets.

    → Used to generate:
        - T4Combined.json
        - T4TrainedCombined.json
    """
    combined_entries = []
    current_index = 0
    current_label = 0

    def load_and_adjust(filepath):
        nonlocal current_index, current_label
        label_map = {}
        updated = []

        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                entry = json.loads(line)
                old_label = entry["label"]
                if old_label not in label_map:
                    label_map[old_label] = current_label
                    current_label += 1

                entry["label"] = label_map[old_label]
                entry["index"] = current_index
                current_index += 1
                updated.append(entry)

        return updated

    for file in input_files:
        combined_entries.extend(load_and_adjust(file))

    with open(output_file, "w", encoding="utf-8") as out:
        for entry in combined_entries:
            json.dump(entry, out)
            out.write("\n")

    print(f"✅ Combined {len(combined_entries)} entries into '{output_file}'")


def split_by_domain_label(input_file, query_file, candidate_file):
    """
    Splits any combined JSONL dataset into query/candidate files.

    → Used for:
        - TestT4Combined.json → TestT4Queries.json, TestT4Candidates.json
    """
    queries = []
    candidates = []

    with open(input_file, "r", encoding="utf-8") as f:
        for line in f:
            entry = json.loads(line)
            if entry["domain_label"] == 0:
                queries.append(entry)
            elif entry["domain_label"] == 1:
                candidates.append(entry)

    with open(query_file, "w", encoding="utf-8") as qf:
        for entry in queries:
            json.dump(entry, qf)
            qf.write("\n")

    with open(candidate_file, "w", encoding="utf-8") as cf:
        for entry in candidates:
            json.dump(entry, cf)
            cf.write("\n")

    print(f"✅ Split into {len(queries)} queries and {len(candidates)} candidates")


#########################################
# ========== MAIN EXAMPLE CALLS ==========
#########################################

if __name__ == "__main__":
    # Example: Convert Java folder to JSON
    convert_java_folder_to_train_json("java_data_folder", "TrainJava.json")

    # Example: Convert C# folder to JSON
    convert_csharp_folder_to_train_json("cs_data_folder", "TrainC.json")

    # Example: Combine parts
    combine_multiple_parts(
        ["TrainJava.json", "TrainC.json", "TrainCSP1.json", "TrainCSP2.json"],
        "T4Combined.json"
    )

    # Example: Split test set into queries/candidates
    split_by_domain_label(
        "TestT4Combined.json",
        "TestT4Queries.json",
        "TestT4Candidates.json"
    )
